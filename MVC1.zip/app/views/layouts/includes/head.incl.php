<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />

<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title> <?= $this->_siteTitle; ?></title>

<link rel="stylesheet" type="text/css" href="<?= CSSDIR ?>bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="<?= JSDIR ?>bootstrap.min.js"></script>