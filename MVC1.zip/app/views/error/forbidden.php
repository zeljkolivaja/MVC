<?php $this->start('head');?>
<?php $this->setSiteTitle("Upload image");?>
<?php $this->end();?>

<?php $this->start('body');?>

<br />

<div class="text-center">
    <h2>You are not allowed to visit this page</h2>
</div>

<?php $this->end();?>