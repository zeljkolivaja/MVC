<?php $this->start('head');?>
<?php $this->setSiteTitle("Upload image");?>
<?php $this->end();?>

<?php $this->start('body');?>

<br />

<div class="text-center">
    <h2>Requested page ( <?php e($message)?>) has not been found</h2>
</div>

<?php $this->end();?>