 <?php

   // configure these setting to get the app working on your server

   //database name
   define('DB_NAME', 'mvc');
   //database user
   define('DB_USER', 'root');
   //database password
   define('DB_PASSWORD', '');
   //our host, use ip adress to avoid dns lookup
   define('DB_HOST', '127.0.0.1');
