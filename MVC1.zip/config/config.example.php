 <?php

// configure these setting to get the app working on your server

//database name
define('DB_NAME', 'ExampleDatabase');
//database user
define('DB_USER', 'ExampleUser');
//database password
define('DB_PASSWORD', 'ExamplePassword');
//our host, use ip adress to avoid dns lookup
define('DB_HOST', 'ExampleIP');